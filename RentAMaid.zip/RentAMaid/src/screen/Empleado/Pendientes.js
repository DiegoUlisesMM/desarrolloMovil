import { SafeAreaView, Text } from "react-native";
import React from "react";

export default function Pendientes() {
    return (
        <SafeAreaView>
            <Text>Pendientes</Text>
        </SafeAreaView>
    );
}
