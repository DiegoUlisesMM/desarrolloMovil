import { View, Text, SafeAreaView } from 'react-native'
import React from 'react'

export default function PostulanteAceptada() {
  return (
    <SafeAreaView>
      <Text>PostulanteAceptada</Text>
    </SafeAreaView>
  )
}